﻿using System;

namespace Ramirez_Aimee_Madlibs {
 class Program {
  static void Main(string[] args) {
   // this is stored in store but lastly called for sentence structure below. 
   //String[] store = new String[7];
   // i. Ask for 1 animal
   string spaces = " ";
   string whoIsLike = "who is like a";
   string hungry = "was hungry for";
   string nameAnimal;
   //ii. Ask for 1 name
   string nameType;
   //iii. Ask for 1 adjective
   string nameAdjective;
   //iv. Ask for 1 food item
   string nameFoodItem;
   //got to get an animal, name, adj, and a food variables.
   Console.WriteLine("Enter your Animal name upon input: ");
     // i. Ask for 1 animal
   nameAnimal = Console.ReadLine();
   Console.WriteLine("Enter your Name Type upon input: ");
     //ii. Ask for 1 name
   nameType = Console.ReadLine();
   Console.WriteLine("Enter your Adjective Type upon input: ");
    //iii. Ask for 1 adjective
   nameAdjective = Console.ReadLine();
   Console.WriteLine("Enter your Food Type upon input: ");
    //got to get an animal, name, adj, and a food variables.
   nameFoodItem = Console.ReadLine();
    // now we need to call the year
   int year;
   Console.WriteLine("Enter a year of choice:");
   year = int.Parse(Console.ReadLine());
    // now we need to call the cost
   decimal moneyYearly;
   Console.WriteLine("Enter a cost like $1.25 etc:");
   moneyYearly = decimal.Parse(Console.ReadLine());
   decimal total = Math.Round(moneyYearly, 2);
    // now we need to call the random number
   decimal randomNumber;
   string grandTotal = total.ToString($"{0:c}");
   Console.WriteLine("input a random number:");
   randomNumber = decimal.Parse(Console.ReadLine());
    // now we need to call the input to put the prompts in.
   string sentenceStruct = "In the year of " + year + "," + " about " + randomNumber + " miles away..." + spaces + nameAdjective + spaces + nameType + spaces +
    whoIsLike + spaces + nameAnimal + spaces + hungry + spaces + nameFoodItem + " which costs " + grandTotal + ".";
   Console.WriteLine(sentenceStruct);
/* Test:
Enter your Animal name upon input:
Doggy
Enter your Name Type upon input:
Aimee
Enter your Adjective Type upon input:
Stupid
Enter your Food Type upon input:
Spagetti
Enter a year of choice:
2019
Enter a cost like $1.25 etc:
1.35
input a random number:
2
In the year of 2019, about 2 miles away... Stupid Aimee who is like a Doggy was hungry for Spagetti which costs $1.35.
 */

  }
 }
}
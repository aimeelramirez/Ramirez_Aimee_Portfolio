﻿using System;

namespace Ramirez_Aimee_Conditionals {
 class Program {
  static void Main(string[] args) {
   ///------ Problem #1: Free Shipping----///
   string pInput1;
   decimal convertInput1, a;
   decimal d = 1.25m;
   string convertCurrency1;
   Console.WriteLine("How many items would you like to order?");
   pInput1 = Console.ReadLine();
   convertInput1 = decimal.Parse(pInput1);
   // now to check for input call
   if (convertInput1 > 4) {
    //“Congratulations,	you	have bought	# > 4 items, so	you	qualify	for	free shipping!”
    Console.WriteLine("“" + "Congratulations, you have bought " + convertInput1 + ", so you qualify for free shipping!" + "”");
   } else if (convertInput1 <= 4) {
    a = d * convertInput1;
    convertCurrency1 = a.ToString($"{0:c}");
 Console.WriteLine("“" + "Your cost for shipping today for " + convertInput1 + " items is " + convertCurrency1 + "." + "”");
   }
   /* Tested: On calculator and command prompt.
   – “Your	cost	for	shipping	today for	2 items	is $2.50.” 
   - “Your	cost	for	shipping	today for	4 items	is $5.00.”
   - “Congratulations,	you	have	bought	5 items,	so	you	qualify	for	free	shipping!”
   -“Congratulations,	you	have	bought	7 items,	so	you	qualify	for	free	shipping!”
   */

   ///---- Problem #2: Mall Employee Discount ----///

   //now i need as cashier to add item values in prompt
   string pInputFirstItem2, pInputSecondItem2;
   string person;
   string yes, no;

    /// this is first item ///
 Console.WriteLine("Let's add your first item cost here: ");
    pInputFirstItem2 = Console.ReadLine();
    decimal numberInputFirstItem2 = decimal.Parse(pInputFirstItem2);
    //double convertInputFirst2 = Math.Round(numberInputFirstItem2, 2); /// <== X;
    //string convertCurrencyFirst2 = convertInputFirst2.ToString($"{0:c}");
    string totalFirstInput = numberInputFirstItem2.ToString($"{0:c}");
 Console.WriteLine("First Item Cost: " + totalFirstInput);
    /// this is second item ///
 Console.WriteLine("Let's add your second item cost here: ");
    pInputSecondItem2 = Console.ReadLine();
    decimal numberInputSecondItem2 = decimal.Parse(pInputSecondItem2);
    // double convertInputSecond2 = Math.Round(numberInputSecondItem2, 2); /// <== X;
    string totalSecondInput = numberInputSecondItem2.ToString($"{0:c}");
 Console.WriteLine("Second Item Cost: " + totalSecondInput);
    // string convertCurrencySecond2 =  convertInputSecond2.ToString($"{0:c}");
    decimal addIt = numberInputFirstItem2 + numberInputSecondItem2;
    //  string subtotal = addIt.ToString();
    string total = addIt.ToString($"{0:c}");
 Console.WriteLine("This is total before asking if employee: " + total);

    //ok I need to know if the person is a customer or a works in the mall or not. 
    // so if yes the get the 10% if not they don't get the discount;
 Console.WriteLine("Hey, are you a customer or do you work in the mall? Type: " + "“" + "yes" + "”" + " or " + "“" + "no" + "”");
    person = Console.ReadLine();
    // let's check if there is a no to yes to answer.
    yes = "yes";
    no = "no";
    if (person != yes) {
     //passing the total over
  Console.WriteLine("“This is total: " + total + "”");
     // if person says no or not yes.
     Console.WriteLine("The person said no! Be kind to customer.");
    } else if (person != no) {
     Console.WriteLine("This person said yes!  this is a mall employee so please offer the discount");

     decimal tenOverHundred = 0.10m;
     decimal tenPerent = addIt * tenOverHundred;
     decimal addTotal = addIt - tenPerent;
     string newTotal = addTotal.ToString($"{0:c}");
  Console.WriteLine("Your total purchase is " + total + ",but with your 10% employee discount it is now " + newTotal);
    }
    /*Tested:
           Test 1
           Hello, are you purchasing items? if so, how many?
           2
           you entered two items, thank you!
           Great let's add your first item cost here:
           65.9
           First Item Cost: $65.90
           Great let's add your second item cost here:
           85
           Second Item Cost: $85.00
           his is total before asking if employee: $150.90
           Hey, are you a customer or do you work in the mall? Type: "yes" or "no"
           yes
           This person said yes!  this is a mall employee so please offer the discount
           Your total purchase is $150.90,but with your 10% employee discount it is now $135.81

                Test 2  
                Hello, are you purchasing items? if so, how many?
                2
                you entered two items, thank you!
                Great let's add your first item cost here:
                19.99
                First Item Cost: $19.99
                Great let's add your second item cost here:
                40.20
                Second Item Cost: $40.20
                This is total before asking if employee: $60.19
                Hey, are you a customer or do you work in the mall? Type: "yes" or "no"
                no
                "This is total: $60.19"   
                 
                 */

   
   ///----- Problem #3:	Apple Pickers ----///
   string pInput3;
   // i need to put the item;
   string produce;
Console.WriteLine("\nThis is Apple Pickers!");
   // what is produce item?
Console.WriteLine("What is your item you are weighting ?");
   produce = Console.ReadLine();
   // weight of item/s?
Console.WriteLine("Let's weight the basket or item in the scale! \nPlease put the value of pounds/lbs in the input below:");
   pInput3 = Console.ReadLine();
   double numberInput3 = double.Parse(pInput3);
   //first comparison need to ask the weight is less than 7
   if (numberInput3 < 7) {
 Console.WriteLine("this is 1.00 per pound");
    string costPerPound1 = numberInput3.ToString($"{0:c}");
 Console.WriteLine("Your basket of " + produce + " of " + numberInput3 + "lbs " + "costs " + costPerPound1 + ".”");
    //Up	To	But	Not	Including	7 lbs.
   } else if (numberInput3 < 15.25) {
 Console.WriteLine("this is 0.90 per pound");
    double row2 = numberInput3 * .90;
    // System.Console.WriteLine("number lbs times .90: " + row2);
    string costPerPound2 = row2.ToString($"{0:c}");
 Console.WriteLine("“Your basket of " + produce + " of " + numberInput3 + "lbs " + "costs " + costPerPound2 + ".”");
   } else if (numberInput3 < 40) {
 Console.WriteLine("this is 0.80 per pound");
    double row3 = numberInput3 * .80;
    // System.Console.WriteLine("number lbs times .80: " + row3);
    string costPerPound3 = row3.ToString($"{0:c}");
 Console.WriteLine("“Your basket of " + produce + " of " + numberInput3 + "lbs " + "costs " + costPerPound3 + ".”");
   } else if (numberInput3 >= 40 && numberInput3 < 70.5) {
 Console.WriteLine("this is 0.70 per pound");
    double row4 = numberInput3 * .70;
    //System.Console.WriteLine("number lbs times .70: " + row4);
    string costPerPound4 = row4.ToString($"{0:c}");
 Console.WriteLine("“Your basket of " + produce + " of " + numberInput3 + "lbs " + "costs " + costPerPound4 + ".”");
   } else if (numberInput3 >= 70.5 && numberInput3 <= 100) {
 Console.WriteLine("this is 0.60 per pound");
    double row5 = numberInput3 * .60;
    //System.Console.WriteLine("number lbs times .60: " + row5);
    string costPerPound5 = row5.ToString($"{0:c}");
 Console.WriteLine("“Your basket of " + produce + " of " + numberInput3 + "lbs " + "costs " + costPerPound5 + ".”");
   } else if (numberInput3 > 100) {
 Console.WriteLine("Congrats! this is greater than 100 lbs! ");
 Console.WriteLine("this is 0.50 per pound");
    double row6 = numberInput3 * .50;
    // System.Console.WriteLine("number lbs times .50: " + row6);
    string costPerPound6 = row6.ToString($"{0:c}");
 Console.WriteLine("“Your basket of " + produce + " of " + numberInput3 + "lbs " + "costs " + costPerPound6 + ".”");
   }
   /*   Some were catchy with the <= 100 in the end to get the right values

          Data	Sets	to	Test:
   o Basket	of	apples	weight	=	4.5
   § Result - “Your	basket	of	apples	of	4.5	lbs.	costs	$4.50.”
   o Pumpkin	weight	=	10
   § Result - “Your	basket	of	apples	of	10	lbs.	costs	$9.00.”
   o Pumpkin	weight	=	15.25
   § Result - “Your	basket	of	apples	of	15.25	lbs.	costs	$12.20.”
   o Basket	of	apples	weight	=	30
   § Result - “Your	basket	of	apples	of	30	lbs12.	costs	$24.00.”
   o Basket	of	apples	weight	=	60.50
   § Result - “Your	basket	of	apples	of	60.50	lbs.	costs	$42.35.”
   o Basket	of	apples	weight	=	100
   § Result - “Your	basket	of	apples	of	100	lbs.	costs	$60.00.”
   o Basket	of	apples	weight	=	150.30
   § Result - “Your	basket	of	apples	of	150.30	lbs.	costs	$75.15.”
   o Test	One	Of	Your	Own.		All	7 of	these	
       */

   ///---- Problem #4: Senior Citizen Discount ----///
Console.WriteLine("\nThis is Senior Discount!");
   string customerInput;
Console.WriteLine("Hello, what is your age? Kindly type it  below: ");
   customerInput = Console.ReadLine();
   double numberCustomerInput = double.Parse(customerInput);
   if (numberCustomerInput <= 6 || numberCustomerInput >= 65) {
 Console.WriteLine("“Your cost for your ticket to Comic Con is $40.00.”");
   } else {
 Console.WriteLine("“Your cost for your ticket to Comic Con is $55.00.”");
   }
   /* Tested:
    68	- “Your	cost	for	your	ticket	to	Comic	Con is $40.00.”
    29 - “Your	cost	for	your	ticket	to	Comic	Con is $55.00.”
    6	- “Your	cost	for	your	ticket	to	Comic	Con is $40.00.”
    7	-	Results	– “Your	cost	for	your	ticket	to	Comic	Con is $55.00.”
    8	-	Results	– “Your	cost	for	your	ticket	to	Comic	Con is $55.00.”
    */
  }
 }
}
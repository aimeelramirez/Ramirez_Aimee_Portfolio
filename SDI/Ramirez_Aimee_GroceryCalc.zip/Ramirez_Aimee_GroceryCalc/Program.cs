﻿using System;

namespace Ramirez_Aimee_GroceryCalc {
 class MainClass {
  public static void Main(string[] args) {
   decimal salesTax;
   string input, input2, input3;
   decimal convertInput, convertInput2, convertInput3;
   decimal convertBanana, convertBeef, convertApple;
   string banana, applePie, beefBrisket;
   Console.WriteLine("In Grocery Store: ... Please input each price for item  in grocery store!");
   Console.WriteLine("Cost of an Banana:" + "\nBanana:");
   banana = Console.ReadLine();
   convertBanana = decimal.Parse(banana);
   Console.WriteLine("Cost of a Beef Brisket:" + "\nBeef Brisket:");
   beefBrisket = Console.ReadLine();
   convertBeef = decimal.Parse(beefBrisket);
   Console.WriteLine("Cost of Apple Pie:" + "\nApple Pie:");
   applePie = Console.ReadLine();
   convertApple = decimal.Parse(applePie);

   Console.WriteLine("Quantity of Bananas: ");
   input = Console.ReadLine();
   convertInput = decimal.Parse(input);
   decimal amount = convertInput * convertBanana;
   string convertAmount = amount.ToString($"{0:c}");

   Console.WriteLine("Quantity of Beef Brisket: ");
   input2 = Console.ReadLine();
   convertInput2 = decimal.Parse(input2);
   decimal amount2 = convertInput2 * convertBeef;
   string convertAmount2 = amount2.ToString($"{0:c}");

   Console.WriteLine("Quantity of Apple Pie: ");
   input3 = Console.ReadLine();
   convertInput3 = decimal.Parse(input3);
   decimal amount3 = convertInput3 * convertApple;
   string convertAmount3 = amount3.ToString($"{0:c}");

   //give them what they asked for upon request
   Console.WriteLine("Amount Bananas you picked: " + input + " will cost you " + convertAmount);
   Console.WriteLine("Amount Beef Brisket you picked: " + input2  + " will cost you " + convertAmount2);
   Console.WriteLine("Amount Apples you picked: " + input3 + " will cost you " + convertAmount3);
   // oops, got to make sure the tax is totaled with subtotal. 
   Console.WriteLine("Please select your tax input if 7% type 7 etc:  ");
   string salesTaxInput = Console.ReadLine();
   decimal convertSalesTaxInput = decimal.Parse(salesTaxInput);
   salesTax = convertSalesTaxInput / 100;
   //what tax did you input.
   Console.WriteLine("Sales Tax in My Area: " + convertSalesTaxInput +"%");
   //calculated the subtotal.
   decimal subtotal = amount + amount2 + amount3;
   string convertSubtotal = subtotal.ToString($"{0:c}");
   Console.WriteLine("subtotal:  " + convertSubtotal);
   //tax total is the input over hundred times the subtotal. 
   decimal taxTotal = subtotal * salesTax;
   decimal grandTaxTotal = Math.Round(taxTotal, 2);
   string convertGrandTaxTotal =  grandTaxTotal.ToString($"{0:c}");

   Console.WriteLine("this is tax total of subtotal:" + convertGrandTaxTotal );
   // what is the total with tax and subtotal.
   decimal total = subtotal + grandTaxTotal;
   //grand total is with the rounding off to the nearest cent. 
  // decimal grandTotal = Math.Round(total, 2);
   string grandTotal = total.ToString($"{0:c}");
   Console.WriteLine("grand total: " + grandTotal + "!");

   /* Test #1:
     Amount Bananas you picked: 4 will cost you $1.60
     Amount Beef Brisket you picked: 2 will cost you $40.50
     Amount Apples you picked: 3 will cost you $29.25
     Please select your tax input if 7% type 7 etc: 5
     Sales Tax in My Area: 5%
     subtotal:  $71.35
     this is tax total of subtotal:$3.57
     grand total: $74.92!
     

     Test #2:
     Amount Bananas you picked: 6 will cost you $4.50
     Amount Beef Brisket you picked: 4 will cost you $52.96
     Amount Apples you picked: 2 will cost you $7.50
     Please select your tax input if 7% type 7 etc:
     9
     Sales Tax in My Area: 9%
     subtotal:  $64.96
     this is tax total of subtotal:$5.85
     grand total: $70.81!
    */

  }
 }
}
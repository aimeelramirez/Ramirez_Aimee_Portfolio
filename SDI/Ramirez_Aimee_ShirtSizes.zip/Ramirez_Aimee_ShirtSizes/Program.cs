﻿using System;

namespace Ramirez_Aimee_ShirtSizes {
 class MainClass {
  public static void Main(string[] args) {
   Console.WriteLine("Hello this is a greeting to the user.");
   //Declare an array called shirtOrders 
   //and define it using the following set of items
  string[] shirtOrders = new string[] {
    "Medium", //2
    "Small", // 3
    "X-Large", //2
    "Small", //
    "Large", //1
    "Medium", //
    "Small", //
    "X-Large", //
    "XX-Large" //1
   }; 
     /*  string[] shirtOrders = new string[] 
        {"XX-Large",	"Medium",	"Large",	"Small",	"X-Large",	"Small",	"Large",	"XX-Large",	"Large",	"XX-Large",	"Medium",	"Medium"}
      ; */
   int smallCounter = 0;
   int medCounter = 0;
   int larCounter = 0;
   int xLarCounter = 0;
   int xXLarCounter = 0;
   string store = " ";
   string storeMed = " ";
   string storeLar = " ";
   string storeXLar = " ";
   string storeXXLar = " ";
   for (int y = 0; y < shirtOrders.Length; y++) {


    if (shirtOrders[y] == "Small") {
     smallCounter += 1;
     //I need to print this once.
     if (y > 0) {
      store = shirtOrders[y];
     }
    }
    if (shirtOrders[y] == "Medium") {
     medCounter += 1;
   //I need to print this once.
     if (y > 0) {
      storeMed = shirtOrders[y];
     }
    }
    if (shirtOrders[y] == "Large") {
     larCounter += 1;
    //I need to print this once.
     if (y > 0) {
      storeLar = shirtOrders[y];
     }

    }
    if (shirtOrders[y] == "X-Large") {
     xLarCounter += 1;
      //I need to print this once.
     if (y > 0) {
      storeXLar = shirtOrders[y];
     }

    }
    if (shirtOrders[y] == "XX-Large") {
     xXLarCounter += 1;
      //I need to print this once.
     if (y > 0) {
      storeXXLar = shirtOrders[y];
     }

    }
    /*Test 1:
    Hello this is a greeting to the user.
    Order 3 Small Shirt(s)
    Order 2 Medium Shirt(s)
    Order 1 Large Shirt(s)
    Order 2 X-Large Shirt(s)
    Order 1 XX-Large Shirt(s)                        
      Test 2:
      Hello this is a greeting to the user.
    Order 2 Small Shirt(s)
    Order 3 Medium Shirt(s)
    Order 3 Large Shirt(s)
    Order 1 X-Large Shirt(s)
    Order 3 XX-Large Shirt(s)   
    Re-Tested the tests.    
        */
   }
   Console.WriteLine("Order {0} {1} Shirt(s)", smallCounter, store);
   Console.WriteLine("Order {0} {1} Shirt(s)", medCounter, storeMed);
   Console.WriteLine("Order {0} {1} Shirt(s)", larCounter, storeLar);
   Console.WriteLine("Order {0} {1} Shirt(s)", xLarCounter, storeXLar);
   Console.WriteLine("Order {0} {1} Shirt(s)", xXLarCounter, storeXXLar);



  }

 }
}
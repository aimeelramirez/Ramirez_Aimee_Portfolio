﻿using System;

namespace Ramirez_Aimee_Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
           
            //// first step: prompt the user for the number of books the user has to buy
            string inputWantingToBuy;
            //decimals of price of books
            decimal numberWantingToBuy;
            string input;

            Console.WriteLine("how many books would you like to purchase?");
            input = Console.ReadLine();
            //number of books
            int check;
            bool isParsed = int.TryParse(input, out check);
            while (string.IsNullOrWhiteSpace(input) ||  !isParsed && check > 0)
            {
                Console.WriteLine("This is not the right input, please try again:");
                input = Console.ReadLine();

            }

            decimal[] myNumbers = new decimal[check];
            // this gets the overall number of price sum in loop
            for (int x = 0; x < myNumbers.Length;)
            {
                // this gets the price of book here to loop
                for (int i = 0; i < myNumbers.Length; i++)
            {

               // Inside of the loop, prompt the user for the cost of a book.
               Console.WriteLine("Put this price of a book here: ");
                inputWantingToBuy = Console.ReadLine();
                //validation
                while (!decimal.TryParse(inputWantingToBuy, out numberWantingToBuy))
        
                {

                    System.Console.WriteLine("This is not the right format, please try again: ");
                    inputWantingToBuy = Console.ReadLine();
                   decimal.TryParse(inputWantingToBuy, out numberWantingToBuy);

                }
                  //You will now need to get the total for all of the books.
                     myNumbers[x] += numberWantingToBuy;
                       }
                        string price = myNumbers[x].ToString($"{0:c}");

                        Console.WriteLine("Your total for {0} books is {1} \n", check, price);  

                       break;

              /* o Test	1:	
                  	Number	of	books	to	buy:	3
                    Put this price of a book here:
                    5.50
                    Put this price of a book here:
                    10.25s        
                    Put this price of a book here:
                    Seventy Dollars
                    This is not the right format, please try again:
                    17.00
                    Your total for 3 books is $32.75

                    Test	2:		
                    Number	of	books	to	buy:	4
                    how many books would you like to purchase?
                    4
                    Put this price of a book here:
                    9.99
                    Put this price of a book here:
                    24.34
                    Put this price of a book here:
                    12
                   Put this price of a book here:
                    25
                   Your total for 4 books is $71.33

                   Checked the tests again to verify.
                  */

                              
            }

            string[] randomThings = { "grapes", "apples", "limes", "lemon", "ball", "carrot", "towel", "laptop", "stove" };
            string[] colors = { "purple", "red", "green", "yellow", "red", "orange", "white", "silver", "black" };
            for (int j = 0; j < randomThings.Length; j++)
            {
              
                System.Console.WriteLine("The main color of " + randomThings[j] + " is " + colors[j] + ".");

            }
           
            
            /*Tested:
            The main color of grapes is purple.
            The main color of apples is red.
            The main color of limes is green.
            The main color of lemon is yellow.
            The main color of ball is red.
            The main color of carrot is orange.
            The main color of towel is white.
            The main color of laptop is silver.
            The main color of stove is black.
             */
        }

    }
}


﻿using System;

namespace Ramirez_Aimee_StringObjects {
 class Program {
  static void Main(string[] args) {
   //get the string of input to be checked
   Console.WriteLine("Enter the numbers for credit card here/n This number needs to be 12-16 numbers in length: ");
   string input;
   input = Console.ReadLine();
   // for(int i = 0;  i <= input.Length;){
   // got to make sure it is not left empty or short in length upon input
   //checking for less than 12 or greater than 16
   while (string.IsNullOrWhiteSpace(input) || input.Length < 12 || input.Length > 16) {
    Console.WriteLine("This is not correct, please try again.");
    input = Console.ReadLine();
   }
   // the input can be less than or equal to what is set but there it needs to have a length limit
   // this gets the count of the length
   CreditCardSensor(input);
   /* --- The Search --- */
   Console.WriteLine("Make a sentence here: ");
   //Text	sentence	to	count
   string inputSearch = Console.ReadLine();
   //let's read this 
   //  Console.WriteLine("{0}", inputSearch);
   while (string.IsNullOrWhiteSpace(inputSearch)) {
    Console.WriteLine("This is not correct, please try again.");
    inputSearch = Console.ReadLine();
   }
   //call the method after FindThe 
   FindThe(inputSearch);
  }
  public static void FindThe(string inputSearchParse) {
   string[] theArray = inputSearchParse.Split(" ");
   //The	number	of	times	the	word	“the”	is	in	the	string	array.
   int storeThe = 0;
   // ok so I saw that it only gets the first of the so i need to get more loop it
   for (int m = 0; m < theArray.Length; m++) {
    if (theArray[m] == "the" || theArray[m] == "The" || theArray[m] == "THE") {
     storeThe += 1;
    }
   }
   Console.WriteLine("Your sentence contains {0} of word(s) and the word `the` appears {1} times. ", theArray.Length, storeThe);
   // I need to store it so that i can call it here outside the loop

  }
  public static void CreditCardSensor(string inputParse) {
   for (int i = 0; i < inputParse.Length;) {
    char[] arr;
    int sum = inputParse.Length;
    sum -= 4;
   // this is to get the characters for the array upon input.
    char[] chars1 = inputParse.ToCharArray();
    for (int x = 0; x < chars1.Length - 4; x++) {
     // this is to call the sentence from concat in "X" to be formed.
     string sentence = string.Concat("X");
     Console.Write("{0}", sentence);
    }
    //this is to get the last 4 in the end of the array.
    arr = inputParse.ToCharArray(sum, 4);
    Console.WriteLine(arr);
    break;
   }


   /*Tested:
   Test #1:
   Enter the numbers for credit card here/n This number needs to be 12-16 numbers in length:
   124569424567
   You can now check out with your credit card ending in: XXXXXXXX4567
   Test #2:
   Enter the numbers for credit card here/n This number needs to be 12-16 numbers in length:
   9876543278564567
   You can now check out with your credit card ending in: XXXXXXXXXXXX4567 
   Test #3:
   Enter the numbers for credit card here/n This number needs to be 12-16 numbers in length:
   123456789012
   You can now check out with your credit card ending in: XXXXXXXX9012
   */

   /* --- The Search --- */
   /*Tested #1:
   Make a sentence here:
   This is a test string to see if the program is working.
   Your sentence contains 12 of word(s) and the word `the` appears 1 times.
   /*Tested #1:
                Make a sentence here:
                This is a test string to see if the program is working.
                Your sentence contains 12 of word(s) and the word `the` appears 1 times.
                
                Tested #2:
                Make a sentence here:
                The best movie that the Redbox machine currently has in stock is The Wolf Of Wall Street.
                Your sentence contains 17 of word(s) and the word `the` appears 3 times.

                Tested #3 (Test if blank):
                Make a sentence here:

                This is not correct, please try again.
                This is a test string to see if the program is working.
                Your sentence contains 12 of word(s) and the word `the` appears 1 times.

                
   Tested #2:
   Make a sentence here:
   The best movie that the Redbox machine currently has in stock is The Wolf Of Wall Street.
   Your sentence contains 17 of word(s) and the word `the` appears 3 times.

   Tested #3 (Test if blank):
   Make a sentence here:

   This is not correct, please try again.
   This is a test string to see if the program is working.
   Your sentence contains 12 of word(s) and the word `the` appears 1 times.

    */

  }
 }
}
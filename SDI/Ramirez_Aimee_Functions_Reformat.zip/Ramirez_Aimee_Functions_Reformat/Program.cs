﻿using System;

namespace Ramirez_Aimee_Functions_Reformat
{
    class Program
    {
        public static void Main(string[] args)
        {
            //---Problem #1:Currency Convertor---//

            //PrintMore();
            decimal parsingCost;
            Console.WriteLine("Put the amount of Euros here:");
            // 1 Euro is worth 1.16 American Dollar
            string input;
            //validate the input upon currency
            input = Console.ReadLine();
            bool isParsed = decimal.TryParse(input, out parsingCost);
            //Ask & Validate In Main Method
            while (!isParsed)
            {

                Console.WriteLine("this is not the right output, please try again");
                input = Console.ReadLine();
                isParsed = decimal.TryParse(input, out parsingCost);
            }
            //Use As Arguments
            decimal results = GetNumber(parsingCost);
            //Then do your final output in the Main.
            //Your output should be rounded to 2 decimal places.
            //You can use Math.Round or .ToString.
            string grandTotal = results.ToString($"{0:c}");
            //Result To Print To The Console In The Main Method:
            Console.WriteLine("{0} euros converted to dollars is {1}", parsingCost, grandTotal);
            /* Tested in Calculator and on Project
                Put the amount of Euros here:
                5.50
                results: 5.50 euros converted to dollars is $6.38
                               
                Put the amount of Euros here:
                15.32
                results: 15.32 euros converted to dollars is $17.77
            */
            //--Problem #2:Astronomical --//

            //Ask & Validate In Main Method
            Console.WriteLine("Put Astronaut's weight on Earth (in pounds): ");
            string inputAstronaut;
            inputAstronaut = Console.ReadLine();
            Console.WriteLine("Thank you this is input for Astronaut:" + inputAstronaut);

            decimal parsingAstronaut;
            bool isAstronomicalParsed = decimal.TryParse(inputAstronaut, out parsingAstronaut);

            string[] planets = new string[]
            {"Mercury","Venus", "Earth", "Mars", "Jupiter", "Saturn","Uranus","Neptune" };
            //1        //2        //3       //4     //5      //6       //7     //8
            while (!isAstronomicalParsed)
            {

                Console.WriteLine("Sorry this is not the right input for number of Planet to be chosen, try again");
                inputAstronaut = Console.ReadLine();
                isAstronomicalParsed = decimal.TryParse(inputAstronaut, out parsingAstronaut);
            }

            /*Tested:
             * Astronaut’s Weight – 210 Planet Choice -9....
             * (Re-prompt because not a valid choice) , New Choice - 5           
             * if the parsingPlanet is greater than 8 that to catch           
            */
           //Menu 
           int counter = 0;
          Console.WriteLine("Menu of Planets:");
           for( int x = 0; x < planets.Length; x++){

            counter += 1;
            Console.WriteLine("{0}: {1}", counter, planets[x]);
           }
            Console.WriteLine("Enter number of Planet:");
            string inputPlanet = Console.ReadLine();
            int parsingPlanet;
            bool isPlanetParsed = int.TryParse(inputPlanet, out parsingPlanet);
            while (!isPlanetParsed || parsingPlanet > 8)
            {

                Console.WriteLine("Sorry this is not the right input for number of Planet to be chosen, try again");
                inputPlanet = Console.ReadLine();
                isPlanetParsed = int.TryParse(inputPlanet, out parsingPlanet);
            }
                int selection = parsingPlanet - 1;
                decimal times;
                decimal storeTimes = 0;
                //Console.Write("Selection :{0}", selection);
                if (planets[selection] == "Mercury")
                {
                //  Console.Write("Planet Selection :{0}", planets[selection]);
                    if(selection >= 0){

                    times = GetWeight(38, parsingAstronaut);
                    storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
                    
                    /* Tested: 1
                     * Mercury                  
                     * 38/100 = 38% = .38                   
                     * 160 * .38 = 60.8lbs                   
                     *                    
                    */
                }
                else if (planets[selection] == "Venus")
                {
                   if(selection > 0){

                    times = GetWeight(91, parsingAstronaut);
                    storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
                   
                    /*Tested: 2
                     * Venus 
                     * 91/100 = 91% = .91;
                     * 160 * .91 = 145.6lbs                    
                    */
                }
                
                else if (planets[selection] == "Earth")
                {   
                     if(selection > 0){

                     times = GetWeight(100, parsingAstronaut);
                     storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
                                    
                   /*Tested: 3
                     * Earth
                     * 100/100 = 100% = 1;
                     * 160 * 1 = 160lbs
                    */
                }
                else if (planets[selection] == "Mars")
                {
                    if(selection > 0){

                    times = GetWeight(38, parsingAstronaut);
                    storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
                                      
                    /*Tested: 4
                     * Mars
                     * 38/100 = 38% = .38;
                     * 160 * .38 = 60.8lbs                 
                     */
                }
                else if (planets[selection] == "Jupiter")
                {
                    if(selection > 0){ 

                    times = GetWeight(234, parsingAstronaut);
                    storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
                
                   /*Tested: 5
                     * Jupiter
                     * 234/100 = 234% = 2.34
                     * 160 * 2.34 = 374.4lbs                   
                    */
                }
                else if (planets[selection] == "Saturn")
                {
                    if(selection > 0){

                    times = GetWeight(93, parsingAstronaut);
                    storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
                  
                    /* Tested: 6
                     * Saturn
                     * 93/100 = 93% = .93;
                     * 160 * .93 = 148.8lbs                    
                   */
                }
                else if (planets[selection] == "Uranus")
                {
                    if(selection > 0){

                    times = GetWeight(92, parsingAstronaut);
                    storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
           
                    /*Tested: 7
                     * Uranus
                     * 92/100 = 92% = .92;
                     * 160 * .92 = 147.2lbs                   
                    */
                }
                else if (planets[selection] == "Neptune")
                {
                    if(selection > 0){

                    times = GetWeight(112, parsingAstronaut);
                    storeTimes += times;
                   }
                  Console.WriteLine("On Earth you weight {0} lbs, but on {1} you would weigh {2} lbs.", parsingAstronaut, planets[selection], storeTimes);
                  
                 /*Tested: 8
                     * Neptune
                     * 112/100 = 112% = 1.12;
                     * 160 * 1.12 = 179.2lbs                   
                    */

              //  }
                /* Tested:
                 * On Earth you weight 210 lbs, but on Jupiter you would weigh 491.4 lbs.”
                 * Retested: All values for each planet and has been double checked with calculator with Tested tests.*/

            }
            //--Problem #3:Dramatic Discounts --//
            /*In this problem, the user will give the program a price and it will tell the user what the cost will be with different discounts applied.
            In the Main, create an array of standard discount percentages. They will be 5, 10, 15, 20, 25 and 30. This array will be hard-coded and will not come from the user.
            Now prompt the user for the price of an item. Make sure to validate this and convert it to the right variable data type for currency.
             */
       
            string inputDiscount;
            decimal parsedDiscount;
            Console.WriteLine("Enter a item price:");
            inputDiscount = Console.ReadLine();
            bool isDiscountParsed = decimal.TryParse(inputDiscount, out parsedDiscount);
            string prettyDiscount = parsedDiscount.ToString($"{0:c}");
            // make the price look pretty in printing out
            Console.WriteLine("Original Cost: " + prettyDiscount);
            Console.WriteLine("Results:");

            while (!isDiscountParsed && parsedDiscount >= 0)
            {

                Console.WriteLine("This is not the correct input, please try again: ");
                inputDiscount = Console.ReadLine();
                isDiscountParsed = decimal.TryParse(inputDiscount, out parsedDiscount);
            }

            // decimal because to easily convert it if so.

            decimal[] dramaticDiscount = new decimal[] { 5, 10, 15, 20, 25, 30 };
            for (int j = 0; j < dramaticDiscount.Length; j++){

                if (j >= 0){

                    decimal getDiscountCalc = DiscountCalc(parsedDiscount, dramaticDiscount[j]);
                    string totalDiscount = getDiscountCalc.ToString($"{0:c}");
                    Console.WriteLine("{0} with a {1}% discount is {2}.",prettyDiscount, dramaticDiscount[j], totalDiscount );
                }
            }
            /*Tested:
                     * Test 1-                   
                     * Enter a item price:
                         10
                        Original Cost: $10.00
                          $10.00 with a 5% discount is $9.50.
                          $10.00 with a 10% discount is $9.00.
                          $10.00 with a 15% discount is $8.50.
                          $10.00 with a 20% discount is $8.00.
                          $10.00 with a 25% discount is $7.50.
                          $10.00 with a 30% discount is $7.00.

                         Tested:
                         Test 2 -
                         Original Cost: $17.99
                            Results:
                             $17.99 with a 5% discount is $17.09.
                             $17.99 with a 10% discount is $16.19.
                             $17.99 with a 15% discount is $15.29.
                             $17.99 with a 20% discount is $14.39.
                             $17.99 with a 25% discount is $13.49.
                             $17.99 with a 30% discount is $12.59.

                        Tested and checked as going the output to be calculated for 
                        array for each over 100 to be calculated, completed test 1 & 2
                          
                        */
        }
        //The custom function you will create should
        // be called DiscountCalc.
        public static decimal DiscountCalc(decimal parDiscountCost, decimal parDiscountVar)
        {

            //It should take in the original price 
            //get the org price from input parsedDiscountCost
           // decimal discountPercentage = parDiscountCost/ 100;
            //and the array element variable 
            //  convert the parDiscountVar/ 100 to get the dec total
            decimal getDiscountVar = parDiscountVar / 100;
            decimal timesDiscount = parDiscountCost * getDiscountVar;
            decimal minusDiscountFromCost = parDiscountCost - timesDiscount;
            return minusDiscountFromCost;

        }
        private static decimal GetWeight(decimal parAstro, decimal parWeight)
        { 
        //So you would send it the original weight...
        //and return the weight on that planet
            decimal weight = parWeight / 100;

            //the "multiplier" for the weight on 
            decimal multiplier = parAstro * weight;
            decimal totalWeight = Math.Round(multiplier, 1);
            return totalWeight;
        }
        //Return Value From Custom Function:
        private static decimal GetNumber(decimal parCost)
        {
            //Amount converted to American Dollars.
            decimal convert = 1.16m;
            decimal total = parCost * convert;
            return total;

        }


    }
}

﻿using System;
using System.Collections.Generic;
namespace Ramirez_Aimee_Lists {
 class Program {
  static void Main(string[] args) { //a. Greet	the	user	and	explain	the	purpose	of	this	program.

   //Console.WriteLine("Create a List of locations that you will visit this year:");
   /*  b. In	the	Main	method,	create	a	List	of	locations	that	the	user	will	visit	this	year.
       i. To	start,	this	List	will	be	blank.
       c. Prompt	the	user	for	a	location	that	they	would	like	to	travel	to	this	year.		
       i. Validate	that	it	is	not	left	blank.
       ii. Make	this	the	first	element	in	the	locations	list.
       */
   List < string > locationList = new List < string > ();
  // locationList.Add("Denmark");
   //locationList.Add("Paris");

   string userResponse;
  Console.WriteLine("\nCreate a List of locations that you will visit this year.");
 
  Console.WriteLine("Yes to continue...No to exit prompt.");
// capture the response 
 // userResponse = Console.ReadLine();
   //would you like to add the trip for the year 
   ///validate the user response yes or no 
   //using userResponse.ToUpper(); 
   //user response is not no 
    while (string.IsNullOrWhiteSpace(userResponse = Console.ReadLine()) ) {
    Console.WriteLine("Sorry this can not be this, Please try again.");
   // userResponse = Console.ReadLine();
     }
   while(userResponse.ToUpper() != "NO"  || userResponse.ToLower() != "no")
   {
// prompt for the city they would like to go to 
   Console.WriteLine("Add a location that you will visit this year... if finished with list, prompt No to exit:  ");
// capture the response 
   userResponse = Console.ReadLine();
// put the response inside the list 
if(userResponse.ToUpper() != "NO"  || userResponse.ToLower() != "no"){
   locationList.Add(userResponse);
// ask again if they would like another trip 
}
   }
   //call the TripOutput method
   //
   TripOutput(locationList); 
   }
   public static void TripOutput (List <string> list){
       //look into display count of list 
         Console.WriteLine("You will take " + list.Count +" trips this year.");
              //You	will	take	4	trips	this	year.
             //loop through list to display locations
             for (int i = 0; i < list.Count; i++) 
            {
                Console.WriteLine("You will visit " + list[i] +" this year.");
            }
    Console.WriteLine("Thank you for using the program and safe travels!");
   }
   /* Test #1:
     You will take 2 trips this year.
     You will visit Italy  this year.
     You will visit England  this year.
     Thank you for using the program and safe travels!
     Test #2:
     You will take 4 trips this year.
     You will visit San Diego this year.
     You will visit Hollywood this year.
     You will visit Las Vegas this year.
     You will visit New York this year.
     Thank you for using the program and safe travels!
    */
  }
 }
  
  
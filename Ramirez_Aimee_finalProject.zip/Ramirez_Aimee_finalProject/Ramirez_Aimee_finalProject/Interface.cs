﻿using System;
using System.Collections.Generic;
namespace Ramirez_Aimee_finalProject
{
        public interface Interface
        {

        public string Water(int water);
        public string Tend(int water, int sow);
        public static Dictionary<int, int> Harvest(Dictionary<int, int> index)
        { return index; }
    }
 }

